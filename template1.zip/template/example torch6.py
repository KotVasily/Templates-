import pandas as pd
import matplotlib.pyplot as plt
import re
 
from torch.utils.data import DataLoader, Dataset 
from transformers import AutoTokenizer, AutoModel
from sklearn.model_selection import train_test_split
import random
import numpy as np
import torch 
import os 
from tqdm import tqdm
from sklearn.metrics import f1_score
import polars

def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)

    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    torch.use_deterministic_algorithms(True)

    os.environ['PYTHONHASHSEED'] = str(seed)
    os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':4096:8'

set_seed(42)

def fast_load(path: str):
    import polars 
    type_ = path.split('.')[-1]
    if type_ == 'csv':
        return polars.read_csv(path, ignore_errors=True)
    if type_ == 'parquet':
        return polars.read_parquet(path)
    else:
        return 'Не распознан'

def mean_pooling(model_output, attention_mask):
    token_embeddings = model_output[0] #First element of model_output contains all token embeddings
    input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
    sum_embeddings = torch.sum(token_embeddings * input_mask_expanded, 1)
    sum_mask = torch.clamp(input_mask_expanded.sum(1), min=1e-9)
    return sum_embeddings / sum_mask

tokenizer = AutoTokenizer.from_pretrained("cointegrated/rubert-tiny2")
model = AutoModel.from_pretrained("cointegrated/rubert-tiny2")
model = model.to('cuda')
model.eval()

items = fast_load('/kaggle/input/path-to-dzen/items.parquet').to_pandas()
items['full_text'] = items['title'] + '\n' + items['content']
text_data = items['full_text'].values.tolist()

embeddings = []

with torch.no_grad():  
    for bath in tqdm(range(0, len(text_data), 64)):
        bath_data = text_data[bath:bath+64]
        encoded_input = tokenizer(bath_data, padding=True, truncation=True, max_length=512, return_tensors='pt').to('cuda')
    
        model_output = model(**encoded_input)
        
        sentence_embeddings = mean_pooling(model_output, encoded_input['attention_mask'])
        for x in sentence_embeddings:
            embeddings.append(x.cpu().numpy().tolist())

items['embeddings'] = embeddings
items.to_parquet('items_add_embeddings.parquet', index=False)
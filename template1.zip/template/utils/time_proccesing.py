import matplotlib.pyplot as plt
import numpy as np  
import pandas as pd
import lightgbm as lgb

from typing import List
from sklearn.model_selection import train_test_split

def get_type_task(eval_metric):
    if eval_metric in ["MAPE", "MAE", "MSE", "RMSE", "R2"]:
        return "reg"
    return "binary" # ["Accuracy", "F1", "AUC", "Precision"]:
    
def get_metric_for_lightgbm(eval_metric):
    if eval_metric in ["MSE", "rmse", "MAPE", "MAE"]:
        return {
            "MSE": "mse",
            "rmse": "rmse",
            "MAPE": "mape",
            "MAE": "mae"
        }[eval_metric] 
    return "mse"

class TimeProccesing:
    def __init__(self, df: pd.DataFrame, time_feature: str, target_column: str, eval_metric: str):
        self.df = df
        self.time_feature = time_feature
        self.target_column = target_column

        self.metric_for_lgbm = get_metric_for_lightgbm(eval_metric) 
        self.type_task = get_type_task(eval_metric) 

    def transform(self) -> pd.DataFrame:
        df, new_features = self.create_time_features(self.df, self.time_feature)
        corr_matrix = df[new_features+['num_sold']].corr()
                
        invalid_features = [col for col in new_features if np.isnan(corr_matrix.loc[col, "num_sold"]) or abs(corr_matrix.loc[col, "num_sold"]) >= 1]
        df = df.drop(columns=invalid_features)
        new_features = [col for col in new_features if col not in invalid_features]

        features_to_remove = set()
        for i in range(len(new_features)):
            if new_features[i] in features_to_remove:
                continue
            for j in range(i+1, len(new_features)):
                if new_features[j] in features_to_remove:
                    continue
                if abs(corr_matrix.loc[new_features[i], new_features[j]]) > 0.95:
                    if abs(corr_matrix.loc[new_features[i], "num_sold"]) < abs(corr_matrix.loc[new_features[j], "num_sold"]):
                        features_to_remove.add(new_features[i])
                        break
                    else:
                        features_to_remove.add(new_features[j])
        
        df = df.drop(columns=features_to_remove)
        new_features = [col for col in new_features if col not in features_to_remove]

        features_importance = self.filter_features_by_importance(df, new_features)
        return df, features_importance

    def create_time_features(self, df: pd.DataFrame, feature: str) -> pd.DataFrame:
        df_copy = df.copy()
        df_copy[feature] = pd.to_datetime(df_copy[feature], errors='coerce')
        df_copy[f'{feature}year'] = df_copy[feature].dt.year
        df_copy[f'{feature}month'] = df_copy[feature].dt.month
        df_copy[f'{feature}day'] = df_copy[feature].dt.day
        df_copy[f'{feature}dayofweek'] = df_copy[feature].dt.dayofweek
        df_copy[f'{feature}dayofyear'] = df_copy[feature].dt.dayofyear
        df_copy[f'{feature}quarter'] = df_copy[feature].dt.quarter
        df_copy[f'{feature}weekofyear'] = df_copy[feature].dt.isocalendar().week
        df_copy[f'{feature}hour'] = df_copy[feature].dt.hour
        df_copy[f'{feature}minute'] = df_copy[feature].dt.minute
        df_copy[f'{feature}second'] = df_copy[feature].dt.second
        df_copy[f'{feature}microsecond'] = df_copy[feature].dt.microsecond
        df_copy[f'{feature}nanosecond'] = df_copy[feature].dt.nanosecond
        df_copy[f'{feature}ismonthstart'] = df_copy[feature].dt.is_month_start
        df_copy[f'{feature}ismonthend'] = df_copy[feature].dt.is_month_end
        df_copy[f'{feature}isquarterstart'] = df_copy[feature].dt.is_quarter_start
        df_copy[f'{feature}isquarterend'] = df_copy[feature].dt.is_quarter_end
        df_copy[f'{feature}isyearstart'] = df_copy[feature].dt.is_year_start
        df_copy[f'{feature}isyearend'] = df_copy[feature].dt.is_year_end
        df_copy[f'{feature}isleapyear'] = df_copy[feature].dt.is_leap_year
        df_copy[f'{feature}daysinmonth'] = df_copy[feature].dt.days_in_month
        df_copy[f'{feature}monthsin'] = np.sin(2 * np.pi * df_copy[feature].dt.month / 12)
        df_copy[f'{feature}monthcos'] = np.cos(2 * np.pi * df_copy[feature].dt.month / 12)
        df_copy[f'{feature}monthsin0.5'] = np.sin(2 * np.pi * df_copy[feature].dt.month / 6)
        df_copy[f'{feature}monthcos0.5'] = np.cos(2 * np.pi * df_copy[feature].dt.month / 6)
        df_copy[f'{feature}daysinsin'] = np.sin(2 * np.pi * df_copy[feature].dt.day / 31)
        df_copy[f'{feature}daysincos'] = np.cos(2 * np.pi * df_copy[feature].dt.day / 31)
        df_copy[f'{feature}daysinsin0.5'] = np.sin(2 * np.pi * df_copy[feature].dt.day / 15)
        df_copy[f'{feature}daysincos0.5'] = np.cos(2 * np.pi * df_copy[feature].dt.day / 15)
        df_copy[f'{feature}dayofweeksin'] = np.sin(2 * np.pi * df_copy[feature].dt.dayofweek / 7)
        df_copy[f'{feature}dayofweekcos'] = np.cos(2 * np.pi * df_copy[feature].dt.dayofweek / 7)
        df_copy[f'{feature}dayofweeksin0.5'] = np.sin(2 * np.pi * df_copy[feature].dt.dayofweek / 3.5)
        df_copy[f'{feature}dayofweekcos0.5'] = np.cos(2 * np.pi * df_copy[feature].dt.dayofweek / 3.5)
        df_copy[f'{feature}dayofyearsin'] = np.sin(2 * np.pi * df_copy[feature].dt.dayofyear / 366)
        df_copy[f'{feature}dayofyearcos'] = np.cos(2 * np.pi * df_copy[feature].dt.dayofyear / 366)
        df_copy[f'{feature}dayofyearsin0.5'] = np.sin(2 * np.pi * df_copy[feature].dt.dayofyear / 183)
        df_copy[f'{feature}dayofyearcos0.5'] = np.cos(2 * np.pi * df_copy[feature].dt.dayofyear / 183)
        df_copy[f'{feature}hoursin'] = np.sin(2 * np.pi * df_copy[feature].dt.hour / 24)
        df_copy[f'{feature}hourcos'] = np.cos(2 * np.pi * df_copy[feature].dt.hour / 24)
        df_copy[f'{feature}hoursin0.5'] = np.sin(2 * np.pi * df_copy[feature].dt.hour / 12)
        df_copy[f'{feature}hourcos0.5'] = np.cos(2 * np.pi * df_copy[feature].dt.hour / 12)
        df_copy[f'{feature}minutesin'] = np.sin(2 * np.pi * df_copy[feature].dt.minute / 60)
        df_copy[f'{feature}minutecos'] = np.cos(2 * np.pi * df_copy[feature].dt.minute / 60)
        df_copy[f'{feature}minutesin0.5'] = np.sin(2 * np.pi * df_copy[feature].dt.minute / 30)
        df_copy[f'{feature}minutecos0.5'] = np.cos(2 * np.pi * df_copy[feature].dt.minute / 30)
        df_copy[f'{feature}secondsin'] = np.sin(2 * np.pi * df_copy[feature].dt.second / 60)
        df_copy[f'{feature}secondcos'] = np.cos(2 * np.pi * df_copy[feature].dt.second / 60)
        df_copy[f'{feature}secondsin0.5'] = np.sin(2 * np.pi * df_copy[feature].dt.second / 30)
        df_copy[f'{feature}secondcos0.5'] = np.cos(2 * np.pi * df_copy[feature].dt.second / 30)
        df_copy[f'{feature}yearmonth'] = df_copy[f'{feature}year'] * 12 + df_copy[f'{feature}month']
        df_copy[f'{feature}yearmonth_day'] = df_copy[f'{feature}year'] * 365 + df_copy[f'{feature}month'] * 30 + df_copy[f'{feature}day']
        df_copy[f'{feature}yearday'] = df_copy[f'{feature}year'] * 365 + df_copy[f'{feature}dayofyear']
        df_copy[f'{feature}monthday'] = df_copy[f'{feature}month'] * 31 + df_copy[f'{feature}day']
        df_copy[f'{feature}hourminute'] = df_copy[f'{feature}hour'] * 60 + df_copy[f'{feature}minute']
        df_copy[f'{feature}minutesecond'] = df_copy[f'{feature}minute'] * 60 + df_copy[f'{feature}second']
        df_copy[f'{feature}hourminute_second'] = df_copy[f'{feature}hour'] * 3600 + df_copy[f'{feature}minute'] * 60 + df_copy[f'{feature}second']
        df_copy[f'{feature}timestamp'] = df_copy[feature].astype(np.int64) // 10**9
        df_copy[f'{feature}daysfromepoch'] = (df_copy[feature] - pd.Timestamp('1970-01-01')) // pd.Timedelta('1D')
        df_copy[f'{feature}secondsfromepoch'] = (df_copy[feature] - pd.Timestamp('1970-01-01')).dt.total_seconds()
        df_copy[f'{feature}isweekend'] = df_copy[feature].dt.dayofweek >= 5
        df_copy[f'{feature}isweekday'] = df_copy[feature].dt.dayofweek < 5
        seasons = {1: 1, 2: 1, 3: 2, 4: 2, 5: 2, 6: 3, 7: 3, 8: 3, 9: 4, 10: 4, 11: 4, 12: 1}
        df_copy[f'{feature}season'] = df_copy[feature].dt.month.map(seasons)
        df_copy[f'{feature}seasonsin'] = np.sin(2 * np.pi * df_copy[f'{feature}season'] / 4)
        df_copy[f'{feature}seasoncos'] = np.cos(2 * np.pi * df_copy[f'{feature}season'] / 4)
        df_copy[f'{feature}quartersin'] = np.sin(2 * np.pi * df_copy[feature].dt.quarter / 4)
        df_copy[f'{feature}quartercos'] = np.cos(2 * np.pi * df_copy[feature].dt.quarter / 4)
        df_copy[f'{feature}weeksin'] = np.sin(2 * np.pi * df_copy[feature].dt.isocalendar().week / 53)
        df_copy[f'{feature}weekcos'] = np.cos(2 * np.pi * df_copy[feature].dt.isocalendar().week / 53)
        time_of_day = pd.cut(df_copy[f'{feature}hour'], bins=[0, 6, 12, 18, 24], labels=['1', '2', '3', '4'],include_lowest=True)
        df_copy[f'{feature}timeofday'] = time_of_day
        df_copy[f'{feature}halfmonth'] = (df_copy[f'{feature}day'] > 15).astype(int)
        df_copy[f'{feature}halfyear'] = (df_copy[f'{feature}month'] > 6).astype(int)
        df_copy[f'{feature}decadeofmonth'] = ((df_copy[f'{feature}day'] - 1) // 10) + 1
        df_copy[f'{feature}weekofmonth'] = ((df_copy[f'{feature}day'] - 1) // 7) + 1
        df_copy[f'{feature}daystoendofmonth'] = df_copy[f'{feature}daysinmonth'] - df_copy[f'{feature}day']
        df_copy[f'{feature}daystoendofyear'] = np.where(df_copy[f'{feature}isleapyear'], 366 - df_copy[f'{feature}dayofyear'], 365 - df_copy[f'{feature}dayofyear'])  
        df_copy[f'{feature}yearprogress'] = np.where(df_copy[f'{feature}isleapyear'],df_copy[f'{feature}dayofyear'] / 366,df_copy[f'{feature}dayofyear'] / 365)
        df_copy[f'{feature}monthprogress'] = df_copy[f'{feature}day'] / df_copy[f'{feature}daysinmonth']
        df_copy[f'{feature}dayprogress'] = (df_copy[f'{feature}hour'] * 3600 + df_copy[f'{feature}minute'] * 60 + df_copy[f'{feature}second']) / 86400
        year_start = pd.to_datetime(df_copy[f'{feature}year'].astype(str) + '-01-01')
        df_copy[f'{feature}dayssinceyearstart'] = (df_copy[feature] - year_start).dt.days
        quarter_month = {1: 1, 2: 1, 3: 1, 4: 4, 5: 4, 6: 4, 7: 7, 8: 7, 9: 7, 10: 10, 11: 10, 12: 10}
        quarter_start = pd.to_datetime(df_copy[f'{feature}year'].astype(str) + '-' + df_copy[f'{feature}month'].map(quarter_month).astype(str) + '-01')
        df_copy[f'{feature}dayssincequarterstart'] = (df_copy[feature] - quarter_start).dt.days
        month_start = pd.to_datetime(df_copy[f'{feature}year'].astype(str) + '-' + df_copy[f'{feature}month'].astype(str) + '-01')
        df_copy[f'{feature}dayssincemonthstart'] = (df_copy[feature] - month_start).dt.days
        df_copy[f'{feature}isnewyear'] = (df_copy[feature].dt.month == 1) & (df_copy[feature].dt.day == 1)
        df_copy[f'{feature}ischristmas'] = (df_copy[feature].dt.month == 12) & (df_copy[feature].dt.day == 25)
        df_copy[f'{feature}iseaster'] = (df_copy[feature].dt.month == 3) & (df_copy[feature].dt.day == 21)
        df_copy[f'{feature}isvalentine'] = (df_copy[feature].dt.month == 2) & (df_copy[feature].dt.day == 14)
        df_copy[f'{feature}iswomensday'] = (df_copy[feature].dt.month == 3) & (df_copy[feature].dt.day == 8)
        df_copy[f'{feature}islaborday'] = (df_copy[feature].dt.month == 5) & (df_copy[feature].dt.day == 1)
        df_copy[f'{feature}isvictoryday'] = (df_copy[feature].dt.month == 5) & (df_copy[feature].dt.day == 9)
        df_copy[f'{feature}isrussiaday'] = (df_copy[feature].dt.month == 6) & (df_copy[feature].dt.day == 12)
        df_copy[f'{feature}ishalloween'] = (df_copy[feature].dt.month == 10) & (df_copy[feature].dt.day == 31)
        df_copy[f'{feature}isthanksgiving'] = (df_copy[feature].dt.month == 11) & (df_copy[feature].dt.day == 24)
        new_features = [col for col in df_copy.columns if col not in df.columns]
        return df_copy, new_features
    
    def filter_features_by_importance(self, df: pd.DataFrame, features: List[str]) -> List[str]:
        df_copy = df.copy()
        df_copy = df_copy.dropna(subset=[self.target_column])
        X = df_copy[features]
        y = df_copy[self.target_column]
        
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        lgb_train = lgb.Dataset(X_train, y_train)
        lgb_eval = lgb.Dataset(X_test, y_test)


        if self.type_task == "reg":
            param = {
                'objective': 'regression',
                'metric': self.metric_for_lgbm,
                'seed': 42,
                'verbosity': -1,
            }
        else:
            param = {
                'objective': 'binary',
                'metric': 'binary_logloss',
                'seed': 42,
                'verbosity': -1,
            }
        
        model = lgb.train(param,
            lgb_train,
            num_boost_round=10000,
            valid_sets=[lgb_train, lgb_eval],
            callbacks=[lgb.early_stopping(stopping_rounds=10)],
        )
        
        return pd.DataFrame({'feature': features, 'importance': model.feature_importance()})

    def code_generate(self, time_feature: str, time_features: List[str]) -> str:
        code = ""
        code += f"import pandas as pd\n" 
        code += f"df['{time_feature}'] = pd.to_datetime(df['{time_feature}'])\n"

        for feature in time_features:
            if feature == f'{time_feature}year':
                code += f"df['{feature}'] = df['{time_feature}'].dt.year\n"
            elif feature == f'{time_feature}month':
                code += f"df['{feature}'] = df['{time_feature}'].dt.month\n"
            elif feature == f'{time_feature}day':
                code += f"df['{feature}'] = df['{time_feature}'].dt.day\n"
            elif feature == f'{time_feature}dayofweek':
                code += f"df['{feature}'] = df['{time_feature}'].dt.dayofweek\n"
            elif feature == f'{time_feature}dayofyear':
                code += f"df['{feature}'] = df['{time_feature}'].dt.dayofyear\n"
            elif feature == f'{time_feature}quarter':
                code += f"df['{feature}'] = df['{time_feature}'].dt.quarter\n"
            elif feature == f'{time_feature}weekofyear':
                code += f"df['{feature}'] = df['{time_feature}'].dt.isocalendar().week\n"
            elif feature == f'{time_feature}hour':
                code += f"df['{feature}'] = df['{time_feature}'].dt.hour\n"
            elif feature == f'{time_feature}minute':
                code += f"df['{feature}'] = df['{time_feature}'].dt.minute\n"
            elif feature == f'{time_feature}second':
                code += f"df['{feature}'] = df['{time_feature}'].dt.second\n"
            elif feature == f'{time_feature}microsecond':
                code += f"df['{feature}'] = df['{time_feature}'].dt.microsecond\n"
            elif feature == f'{time_feature}nanosecond':
                code += f"df['{feature}'] = df['{time_feature}'].dt.nanosecond\n"
            elif feature == f'{time_feature}ismonthstart':
                code += f"df['{feature}'] = df['{time_feature}'].dt.is_month_start\n"
            elif feature == f'{time_feature}ismonthend':
                code += f"df['{feature}'] = df['{time_feature}'].dt.is_month_end\n"
            elif feature == f'{time_feature}isquarterstart':
                code += f"df['{feature}'] = df['{time_feature}'].dt.is_quarter_start\n"
            elif feature == f'{time_feature}isquarterend':
                code += f"df['{feature}'] = df['{time_feature}'].dt.is_quarter_end\n"
            elif feature == f'{time_feature}isyearstart':
                code += f"df['{feature}'] = df['{time_feature}'].dt.is_year_start\n"
            elif feature == f'{time_feature}isyearend':
                code += f"df['{feature}'] = df['{time_feature}'].dt.is_year_end\n"
            elif feature == f'{time_feature}isleapyear':
                code += f"df['{feature}'] = df['{time_feature}'].dt.is_leap_year\n"
            elif feature == f'{time_feature}daysinmonth':
                code += f"df['{feature}'] = df['{time_feature}'].dt.days_in_month\n"
            elif feature == f'{time_feature}monthsin':
                code += f"df['{feature}'] = np.sin(2 * np.pi * df['{time_feature}'].dt.month / 12)\n"
            elif feature == f'{time_feature}monthcos':
                code += f"df['{feature}'] = np.cos(2 * np.pi * df['{time_feature}'].dt.month / 12)\n"
            elif feature == f'{time_feature}monthsin0.5':
                code += f"df['{feature}'] = np.sin(2 * np.pi * df['{time_feature}'].dt.month / 6)\n"
            elif feature == f'{time_feature}monthcos0.5':
                code += f"df['{feature}'] = np.cos(2 * np.pi * df['{time_feature}'].dt.month / 6)\n"
            elif feature == f'{time_feature}daysinsin':
                code += f"df['{feature}'] = np.sin(2 * np.pi * df['{time_feature}'].dt.day / 31)\n"
            elif feature == f'{time_feature}daysincos':
                code += f"df['{feature}'] = np.cos(2 * np.pi * df['{time_feature}'].dt.day / 31)\n"
            elif feature == f'{time_feature}daysinsin0.5':
                code += f"df['{feature}'] = np.sin(2 * np.pi * df['{time_feature}'].dt.day / 15)\n"
            elif feature == f'{time_feature}daysincos0.5':
                code += f"df['{feature}'] = np.cos(2 * np.pi * df['{time_feature}'].dt.day / 15)\n"
            elif feature == f'{time_feature}dayofweeksin':
                code += f"df['{feature}'] = np.sin(2 * np.pi * df['{time_feature}'].dt.dayofweek / 7)\n"
            elif feature == f'{time_feature}dayofweekcos':
                code += f"df['{feature}'] = np.cos(2 * np.pi * df['{time_feature}'].dt.dayofweek / 7)\n"
            elif feature == f'{time_feature}dayofweeksin0.5':
                code += f"df['{feature}'] = np.sin(2 * np.pi * df['{time_feature}'].dt.dayofweek / 3.5)\n"
            elif feature == f'{time_feature}dayofweekcos0.5':
                code += f"df['{feature}'] = np.cos(2 * np.pi * df['{time_feature}'].dt.dayofweek / 3.5)\n"
            elif feature == f'{time_feature}dayofyearsin':
                code += f"df['{feature}'] = np.sin(2 * np.pi * df['{time_feature}'].dt.dayofyear / 366)\n"
            elif feature == f'{time_feature}dayofyearcos':
                code += f"df['{feature}'] = np.cos(2 * np.pi * df['{time_feature}'].dt.dayofyear / 366)\n"
            elif feature == f'{time_feature}dayofyearsin0.5':
                code += f"df['{feature}'] = np.sin(2 * np.pi * df['{time_feature}'].dt.dayofyear / 183)\n"
            elif feature == f'{time_feature}dayofyearcos0.5':
                code += f"df['{feature}'] = np.cos(2 * np.pi * df['{time_feature}'].dt.dayofyear / 183)\n"
            elif feature == f'{time_feature}hoursin':
                code += f"df['{feature}'] = np.sin(2 * np.pi * df['{time_feature}'].dt.hour / 24)\n"
            elif feature == f'{time_feature}hourcos':
                code += f"df['{feature}'] = np.cos(2 * np.pi * df['{time_feature}'].dt.hour / 24)\n"
            elif feature == f'{time_feature}hoursin0.5':
                code += f"df['{feature}'] = np.sin(2 * np.pi * df['{time_feature}'].dt.hour / 12)\n"
            elif feature == f'{time_feature}hourcos0.5':
                code += f"df['{feature}'] = np.cos(2 * np.pi * df['{time_feature}'].dt.hour / 12)\n"
            elif feature == f'{time_feature}minutesin':
                code += f"df['{feature}'] = np.sin(2 * np.pi * df['{time_feature}'].dt.minute / 60)\n"
            elif feature == f'{time_feature}minutecos':
                code += f"df['{feature}'] = np.cos(2 * np.pi * df['{time_feature}'].dt.minute / 60)\n"
            elif feature == f'{time_feature}minutesin0.5':
                code += f"df['{feature}'] = np.sin(2 * np.pi * df['{time_feature}'].dt.minute / 30)\n"
            elif feature == f'{time_feature}minutecos0.5':
                code += f"df['{feature}'] = np.cos(2 * np.pi * df['{time_feature}'].dt.minute / 30)\n"
            elif feature == f'{time_feature}secondsin':
                code += f"df['{feature}'] = np.sin(2 * np.pi * df['{time_feature}'].dt.second / 60)\n"
            elif feature == f'{time_feature}secondcos':
                code += f"df['{feature}'] = np.cos(2 * np.pi * df['{time_feature}'].dt.second / 60)\n"
            elif feature == f'{time_feature}secondsin0.5':
                code += f"df['{feature}'] = np.sin(2 * np.pi * df['{time_feature}'].dt.second / 30)\n"
            elif feature == f'{time_feature}secondcos0.5':
                code += f"df['{feature}'] = np.cos(2 * np.pi * df['{time_feature}'].dt.second / 30)\n"
            elif feature == f'{time_feature}yearmonth':
                code += f"df['{feature}'] = df['{time_feature}year'] * 12 + df['{time_feature}month']\n"
            elif feature == f'{time_feature}yearmonth_day':
                code += f"df['{feature}'] = df['{time_feature}year'] * 365 + df['{time_feature}month'] * 30 + df['{time_feature}day']\n"
            elif feature == f'{time_feature}yearday':
                code += f"df['{feature}'] = df['{time_feature}year'] * 365 + df['{time_feature}dayofyear']\n"
            elif feature == f'{time_feature}monthday':
                code += f"df['{feature}'] = df['{time_feature}month'] * 31 + df['{time_feature}day']\n"
            elif feature == f'{time_feature}hourminute':
                code += f"df['{feature}'] = df['{time_feature}hour'] * 60 + df['{time_feature}minute']\n"
            elif feature == f'{time_feature}minutesecond':
                code += f"df['{feature}'] = df['{time_feature}minute'] * 60 + df['{time_feature}second']\n"
            elif feature == f'{time_feature}hourminute_second':
                code += f"df['{feature}'] = df['{time_feature}hour'] * 3600 + df['{time_feature}minute'] * 60 + df['{time_feature}second']\n"
            elif feature == f'{time_feature}timestamp':
                code += f"df['{feature}'] = df['{time_feature}'].astype(np.int64) // 10**9\n"
            elif feature == f'{time_feature}daysfromepoch':
                code += f"df['{feature}'] = (df['{time_feature}'] - pd.Timestamp('1970-01-01')) // pd.Timedelta('1D')\n"
            elif feature == f'{time_feature}secondsfromepoch':
                code += f"df['{feature}'] = (df['{time_feature}'] - pd.Timestamp('1970-01-01')).dt.total_seconds()\n"
            elif feature == f'{time_feature}isweekend':
                code += f"df['{feature}'] = df['{time_feature}'].dt.dayofweek >= 5\n"
            elif feature == f'{time_feature}isweekday':
                code += f"df['{feature}'] = df['{time_feature}'].dt.dayofweek < 5\n"
            elif feature == f'{time_feature}season':
                code += f"seasons = {{1: 1, 2: 1, 3: 2, 4: 2, 5: 2, 6: 3, 7: 3, 8: 3, 9: 4, 10: 4, 11: 4, 12: 1}}\n"
                code += f"df['{feature}'] = df['{time_feature}'].dt.month.map(seasons)\n"
            elif feature == f'{time_feature}seasonsin':
                code += f"df['{feature}'] = np.sin(2 * np.pi * df['{time_feature}season'] / 4)\n"
            elif feature == f'{time_feature}seasoncos':
                code += f"df['{feature}'] = np.cos(2 * np.pi * df['{time_feature}season'] / 4)\n"
            elif feature == f'{time_feature}quartersin':
                code += f"df['{feature}'] = np.sin(2 * np.pi * df['{time_feature}'].dt.quarter / 4)\n"
            elif feature == f'{time_feature}quartercos':
                code += f"df['{feature}'] = np.cos(2 * np.pi * df['{time_feature}'].dt.quarter / 4)\n"
            elif feature == f'{time_feature}weeksin':
                code += f"df['{feature}'] = np.sin(2 * np.pi * df['{time_feature}'].dt.isocalendar().week / 53)\n"
            elif feature == f'{time_feature}weekcos':
                code += f"df['{feature}'] = np.cos(2 * np.pi * df['{time_feature}'].dt.isocalendar().week / 53)\n"
            elif feature == f'{time_feature}timeofday':
                code += f"time_of_day = pd.cut(df['{time_feature}hour'], bins=[0, 6, 12, 18, 24], labels=['1', '2', '3', '4'],include_lowest=True)\n"
                code += f"df['{feature}'] = time_of_day\n"
            elif feature == f'{time_feature}halfmonth':
                code += f"df['{feature}'] = (df['{time_feature}day'] > 15).astype(int)\n"
            elif feature == f'{time_feature}halfyear':
                code += f"df['{feature}'] = (df['{time_feature}month'] > 6).astype(int)\n"
            elif feature == f'{time_feature}decadeofmonth':
                code += f"df['{feature}'] = ((df['{time_feature}day'] - 1) // 10) + 1\n"
            elif feature == f'{time_feature}weekofmonth':
                code += f"df['{feature}'] = ((df['{time_feature}day'] - 1) // 7) + 1\n"
            elif feature == f'{time_feature}daystoendofmonth':
                code += f"df['{feature}'] = df['{time_feature}daysinmonth'] - df['{time_feature}day']\n"
            elif feature == f'{time_feature}daystoendofyear':
                code += f"df['{feature}'] = np.where(df['{time_feature}isleapyear'], 366 - df['{time_feature}dayofyear'], 365 - df['{time_feature}dayofyear'])\n"
            elif feature == f'{time_feature}yearprogress':
                code += f"df['{feature}'] = np.where(df['{time_feature}isleapyear'],df['{time_feature}dayofyear'] / 366,df['{time_feature}dayofyear'] / 365)\n"
            elif feature == f'{time_feature}monthprogress':
                code += f"df['{feature}'] = df['{time_feature}day'] / df['{time_feature}daysinmonth']\n"
            elif feature == f'{time_feature}dayprogress':
                code += f"df['{feature}'] = (df['{time_feature}hour'] * 3600 + df['{time_feature}minute'] * 60 + df['{time_feature}second']) / 86400\n"
            elif feature == f'{time_feature}dayssinceyearstart':
                code += f"year_start = pd.to_datetime(df['{time_feature}'].dt.year.astype(str) + '-01-01')\n"
                code += f"df['{feature}'] = (df['{time_feature}'] - year_start).dt.days\n"
            elif feature == f'{time_feature}dayssincequarterstart':
                code += f"quarter_month = {{1: 1, 2: 1, 3: 1, 4: 4, 5: 4, 6: 4, 7: 7, 8: 7, 9: 7, 10: 10, 11: 10, 12: 10}}\n"
                code += f"quarter_start = pd.to_datetime(df['{time_feature}'].dt.year.astype(str) + '-' + df['{time_feature}'].dt.month.map(quarter_month).astype(str) + '-01')\n"
                code += f"df['{feature}'] = (df['{time_feature}'] - quarter_start).dt.days\n"
            elif feature == f'{time_feature}dayssincemonthstart':
                code += f"month_start = pd.to_datetime(df['{time_feature}'].dt.year.astype(str) + '-' + df['{time_feature}'].dt.month.astype(str) + '-01')\n"
                code += f"df['{feature}'] = (df['{time_feature}'] - month_start).dt.days\n"
            elif feature == f'{time_feature}isnewyear':
                code += f"df['{feature}'] = (df['{time_feature}'].dt.month == 1) & (df['{time_feature}'].dt.day == 1)\n"
            elif feature == f'{time_feature}ischristmas':
                code += f"df['{feature}'] = (df['{time_feature}'].dt.month == 12) & (df['{time_feature}'].dt.day == 25)\n"
            elif feature == f'{time_feature}iseaster':
                code += f"df['{feature}'] = (df['{time_feature}'].dt.month == 3) & (df['{time_feature}'].dt.day == 21)\n"
            elif feature == f'{time_feature}isvalentine':
                code += f"df['{feature}'] = (df['{time_feature}'].dt.month == 2) & (df['{time_feature}'].dt.day == 14)\n"
            elif feature == f'{time_feature}iswomensday':
                code += f"df['{feature}'] = (df['{time_feature}'].dt.month == 3) & (df['{time_feature}'].dt.day == 8)\n"
            elif feature == f'{time_feature}islaborday':
                code += f"df['{feature}'] = (df['{time_feature}'].dt.month == 5) & (df['{time_feature}'].dt.day == 1)\n"
            elif feature == f'{time_feature}isvictoryday':
                code += f"df['{feature}'] = (df['{time_feature}'].dt.month == 5) & (df['{time_feature}'].dt.day == 9)\n"
            elif feature == f'{time_feature}isrussiaday':
                code += f"df['{feature}'] = (df['{time_feature}'].dt.month == 6) & (df['{time_feature}'].dt.day == 12)\n"
            elif feature == f'{time_feature}ishalloween':
                code += f"df['{feature}'] = (df['{time_feature}'].dt.month == 10) & (df['{time_feature}'].dt.day == 31)\n"
            elif feature == f'{time_feature}isthanksgiving':
                code += f"df['{feature}'] = (df['{time_feature}'].dt.month == 11) & (df['{time_feature}'].dt.day == 24)\n"
        return code
    
if __name__ == "__main__":
    df = pd.read_csv("data.csv")
    time_feature = "date"
    target_column = "num_sold"
    eval_metric = "rmse"
    time_proccesing = TimeProccesing(df, time_feature, target_column, eval_metric)
    df_, time_importance = time_proccesing.transform()
    print("Сгенерированный код: ")
    print(time_proccesing.code_generate(time_feature, time_importance.feature.tolist()))
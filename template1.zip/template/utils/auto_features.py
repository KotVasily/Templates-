import numpy as np
import pandas as pd
import polars as pl 
import warnings
from copy import deepcopy
warnings.filterwarnings("ignore") 

def fast_corr(df: pd.DataFrame, target_col: str) -> pd.Series:
    pl_df = pl.from_pandas(df)
    numeric_cols = pl_df.select(pl.col(pl.Float64, pl.Int64)).columns

    corr_exprs = []
    for col in numeric_cols:
        if col != target_col:
            corr_expr = pl.corr(pl.col(col), pl.col(target_col)).abs().alias(col)
            corr_exprs.append(corr_expr)

    corr_df = pl_df.select(corr_exprs).to_pandas()
    corr_series = corr_df.iloc[0].sort_values(ascending=False)
    return corr_series

def best_features_filter(df, target_col, quantile: float = 0.9):
    corr_result = fast_corr(df, target_col)
    threshold = corr_result.quantile(quantile)
    return corr_result[corr_result > threshold].index.tolist()

def auto_generate_with_pandas_conversion(df_pd, col, target_col, type_features="*", col_features=['gdp']):
    df = pl.DataFrame(df_pd)
    all_col = set()
    drop_col = []
    
    for i1 in col_features: 
        for i2 in col:
            col_ = sorted([i1, i2])
            new_feature_name = f"{col_[0]}-{col_[1]}"

            if i1 != i2 and new_feature_name not in list(all_col):
                if type_features == '*':
                    df = df.with_columns(
                        (pl.col(col_[0]) * pl.col(col_[1])).alias(f"{new_feature_name}_mul")
                    )
                    new_feature = f"{new_feature_name}_mul"
                elif type_features == '/':
                    df = df.with_columns(
                        (pl.col(col_[0]) / pl.col(col_[1])).alias(f"{new_feature_name}_div")
                    )
                    new_feature = f"{new_feature_name}_div" 
                elif type_features == '-':
                    df = df.with_columns(
                        (pl.col(col_[0]) - pl.col(col_[1])).alias(f"{new_feature_name}_sub")
                    )
                    new_feature = f"{new_feature_name}_sub"
                elif type_features == '+':
                    df = df.with_columns(
                        (pl.col(col_[0]) + pl.col(col_[1])).alias(f"{new_feature_name}_mod")
                    )
                    new_feature = f"{new_feature_name}_mod"

                train = df.filter(pl.col("DATA") == "TRAIN")
                corr_target = train.select(pl.corr(new_feature, target_col).abs()).item()
                corr_zero = train.select(pl.corr(col_[0], target_col).abs()).item()
                corr_first = train.select(pl.corr(col_[1], target_col).abs()).item()

                if corr_target > corr_zero and corr_target > corr_first:
                    all_col.add(new_feature)
                else:
                    drop_col.append(new_feature)

    all_col = list(all_col)
    if len(drop_col) > 0:
        df = df.drop(drop_col)

    df_pd_modified = df.to_pandas() 
    return all_col, df_pd_modified

def create_features(df: pd.DataFrame, target_col: str, quantile: float = 0.9, drop_col: list = ['id'], quantile1: float = 0.9, 
        type_task: str = "reg", eval_metric: str = "rmse"):
     
    df_copy = df.copy()
    col = df_copy.drop(columns=drop_col+[target_col]).select_dtypes(['float', 'int']).columns.tolist()
    col_final = [c for c in col if df_copy[c].unique().size > 2]

    dict_col = {} 
    features = best_features_filter(df_copy[col_final+[target_col]], target_col, quantile=quantile1)
    all_new_features = [] 

    for c in features:
        all_col1, df_copy = auto_generate_with_pandas_conversion(df_copy, col_final, target_col, type_features='*', col_features=[c, ])
        all_col2, df_copy = auto_generate_with_pandas_conversion(df_copy, col_final, target_col, type_features='/', col_features=[c, ])
        all_col3, df_copy = auto_generate_with_pandas_conversion(df_copy, col_final, target_col, type_features='+', col_features=[c, ])
        all_col4, df_copy = auto_generate_with_pandas_conversion(df_copy, col_final, target_col, type_features='-', col_features=[c, ])

        dict_col[len(all_col4+all_col3+all_col2+all_col1)] = (c, all_col4+all_col3+all_col2+all_col1)
        all_new_features += all_col4+all_col3+all_col2+all_col1
        print(f"{c} = {len(all_col4+all_col3+all_col2+all_col1)}")

    if list(set(all_new_features)) != []:
        best_features = best_features_filter(df_copy[list(set(all_new_features)) + [target_col]], target_col, quantile=quantile)


        drop_col = [] 

        for c in list(set(all_new_features)): 
            if c not in best_features: 
                drop_col.append(c)

        df_copy = df_copy.drop(columns=drop_col)

        print(f"Все созданные признаки: {list(set(all_new_features))}")
        print("Лучшие признаки: ", list(set(best_features)))
        return df_copy, list(set(best_features)) 
    else: 
        return df, [] 

def get_feature_creation_code(feature_names: list) -> str:
    code_lines = []
    
    for feature in feature_names:
        operation = feature[-3:]
        col1, col2 = feature[:-4].split('-')

        if operation == 'mod':
            code_lines.append(f"df['{feature}'] = df['{col1}'] + df['{col2}']")
        elif operation == 'mul':
            code_lines.append(f"df['{feature}'] = df['{col1}'] * df['{col2}']")
        elif operation == 'div':
            code_lines.append(f"df['{feature}'] = df['{col1}'] / df['{col2}']")
        elif operation == 'sub':
            code_lines.append(f"df['{feature}'] = df['{col1}'] - df['{col2}']")

    return '\n'.join(code_lines)

if __name__ == "__main__":
    df = pd.read_csv("train.csv")
    df['DATA'] = "TRAIN"
    df, best_features = create_features(df, target_col="Transported", quantile=0.9, drop_col=["PassengerId"])
    print(get_feature_creation_code(best_features))
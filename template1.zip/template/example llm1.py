import json
import os
import re
import time 
import torch  

from typing import List, Tuple
from tqdm import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer

NEUTRAL_ANSWER = "я не знаю"
think_prompt = "ответь на вопрос, Перепроверь свой ответ. Убедись, что он не содержит ошибок и неточностей"

SYSTEM_PROMT = []

def read_input(path: str) -> List[str]:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return [str(x) for x in data]


def write_output(path: str, answers: List[str]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(answers, f, ensure_ascii=False)

def postprocess(text: str) -> str:
    return text.strip()

def find_model_dir() -> str:
    return "model"


def load_llm():
    model_dir = find_model_dir()
    device = "cuda" if (torch is not None and torch.cuda.is_available()) else "cpu"
    tok = AutoTokenizer.from_pretrained(model_dir, use_fast=True, trust_remote_code=True)

    mdl = AutoModelForCausalLM.from_pretrained(
        model_dir, 
        torch_dtype="auto",
        device_map="auto",
        trust_remote_code=True,
    )

    if tok.pad_token is None and tok.eos_token is not None:
        tok.pad_token = tok.eos_token

    return mdl, tok

def build_prompt(question: str, tokenizer) -> str:
    user = f"Вопрос: {question} {think_prompt}"

    messages = [{"role": "user", "content": user}]
    return tokenizer.apply_chat_template(messages, tokenize=False,add_generation_prompt=True)

def build_promt_reduce(predict: str, question: str, tokenizer) -> str:
    prompt = 'Преобразуй полный ответ на вопрос в максимально краткий ответ. Делай проверку ответа что он точно отвечает на вопрос.'
    user = f"Вопрос: {question}\nПолный текст ответа: {predict}\n{prompt}"
    messages = [{"role": "user", "content": user}]
    return tokenizer.apply_chat_template(messages, tokenize=False,add_generation_prompt=True)

def answer_questions(model, tokenizer, questions: List[str], batch_size: int = 32) -> List[str]:
    device = model.device
    prompts = [build_prompt(q, tokenizer) for q in questions]
    valid_data = [(i, p) for i, p in enumerate(prompts) if p is not None]
    answers = [NEUTRAL_ANSWER] * len(questions)
    
    for batch_start in tqdm(range(0, len(valid_data), batch_size)):
        batch = valid_data[batch_start:batch_start + batch_size]
        batch_indices, batch_prompts = zip(*batch)
        
        encoded = tokenizer(list(batch_prompts), return_tensors="pt", padding=True, 
            truncation=True).to(device)
        
        gen = model.generate(**encoded, max_new_tokens=512, do_sample=False, num_beams=1)
        
        prompt_len = encoded["input_ids"].shape[1]
        outs = [tokenizer.decode(g[prompt_len:], skip_special_tokens=True) for g in gen]
        
        for idx, out in zip(batch_indices, outs):
            answers[idx] = postprocess(out)
    
    return answers

def reduce_answer(model, tokenizer, data: List[Tuple[str, str]], batch_size: int = 32) -> List[str]:
    device = model.device
    prompts = [build_promt_reduce(a, q, tokenizer) for a, q in data]
    valid_data = [(i, p) for i, p in enumerate(prompts) if p is not None]
    answers = [NEUTRAL_ANSWER] * len(data)
    
    for batch_start in tqdm(range(0, len(valid_data), batch_size)):
        batch = valid_data[batch_start:batch_start + batch_size]
        batch_indices, batch_prompts = zip(*batch)
        
        encoded = tokenizer(list(batch_prompts), return_tensors="pt", padding=True, 
            truncation=True).to(device)
        
        gen = model.generate(**encoded, max_new_tokens=512, do_sample=False, num_beams=1)
        
        prompt_len = encoded["input_ids"].shape[1]
        outs = [tokenizer.decode(g[prompt_len:], skip_special_tokens=True) for g in gen]
        
        for idx, out in zip(batch_indices, outs):
            answers[idx] = postprocess(out)
    
    return answers

def main() -> None:
    start = time.perf_counter()
    model, tokenizer = load_llm()
    questions = read_input("input.json")
    answers = answer_questions(model, tokenizer, questions)
    new_data = [(a, q) for a, q in zip(answers, questions)]
    answers = reduce_answer(model, tokenizer, new_data)
    write_output("output.json", answers)
    
    print(f'Затраченно времени: {time.perf_counter() - start}')


if __name__ == "__main__":
    main() 